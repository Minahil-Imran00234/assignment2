#include<iostream>
using namespace std;
class String
{
private:
	char* ch;

public:
	String();  //default constructor
	String(const String& str);  //copy constructor
	String(const String& str, int pos, int len);  //Overloaded constructor for substring
	String(const char* s); //Overloaded constructor for substring c-string
	String(const char* s, int n);  //Overloaded constructor from the sequence
	String(int n, char c);  //Overloaded constructor for fill
	int length();   //Return length of the string
	char at(int i);   //Get a character in the string
	String substr(int pos, int len) const;  // Sub-string

	friend ostream& operator<< (ostream& os, const String& str)   //Operator <<
	{
		if (str.ch != nullptr)
			os << str.ch << endl;
		return os;
	}

};


