#include <iostream>
#include "String.h"
using namespace std;

String::String()
{
     ch = nullptr;
}

String::String(const String& str)
{
	int s = 0;

	while (1)
	{
		if (str.ch[s] == '\0')
			break;

		s++;
	}

	ch = new char[s + 1];

	for (int i = 0; i < s; i++)
	{
		ch[i] = str.ch[i];
	}

	ch[s] = '\0';
}

String::String(const String& str, int pos, int len)
{
	ch = new char[len + 1];

	int j = pos;
	for (int i = 0; i < len; i++)
	{
		ch[i] = str.ch[j];
		j++;
	}
	ch[len] = '\0';
}
String::String(const char* s)
{
	int length = 0;
	for (int i = 0; s[i] != '\0'; i++)
	{
		length++;
	}

	ch = new char[length + 1];

	for (int i = 0; i < length; i++)
	{
		ch[i] = s[i];
	}
	ch[length] = '\0';
}
String::String(const char* s, int n)
{
	ch = new char[n];

	for (int i = 0; i < n; i++)
	{
		ch[i] = s[i];
	}
	ch[n] = '\0';
}

String::String(int n, char c)
{
	ch = new char[n];

	for (int i = 0; i < n; i++)
	{
		ch[i] = c;
	}
	ch[n] = '\0';
}

int String::length()
{
	int len = 0;
	for (int i = 0; ch[i] != '\0'; i++)
	{
		len++;
	}
	return len;
}

char String::at(int i)
{
	return ch[i];
}

String String::substr(int pos, int len) const
{
	String temp;

	temp.ch = new char[len];

	int j = pos;
	for (int i = 0; i < len; i++)
	{
		temp.ch[i] = ch[j];
		j++;
	}
	temp.ch[len] = '\0';

	return temp;
}
